import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { QuantityPipe } from './quantity.pipe';
import { CourseComponent } from './course/course.component';
import { CourseService } from './course/course.service';
import { ProductService } from './product/product.service';
import { PostsComponent } from './posts/posts.component';
import {HttpClientModule} from '@angular/common/http';
import { PostsService } from './posts/posts.service';
import { ProductAPIService } from './product/productwithhttp.service';
import { PostDetailsComponent } from './post-details/post-details.component';

const routes:Routes = [
  {path:'',component:ShoppingCartComponent},
  {path:'posts',component:PostsComponent},
  {path:'post/:id',component:PostDetailsComponent},
  {path:'courses',component:CourseComponent},
  {path:'**',redirectTo:'/'}

];



@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    ShoppingCartComponent,QuantityPipe,
     CourseComponent, PostsComponent, 
     PostDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers:[CourseService,
    ProductService,
    ProductAPIService],
  bootstrap: [AppComponent]
})
export class AppModule { }
