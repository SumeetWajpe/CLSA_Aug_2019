import { Component, OnInit } from '@angular/core';
import { CourseService } from './course.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
 // ,  providers:[CourseService]
})
export class CourseComponent implements OnInit {
newCourse:string="";
  constructor(private servObj:CourseService) {
    //console.log(this.servObj.courses)
   }

   AddCourse(){
     // biz logic
     this.servObj.AddANewCourse(this.newCourse)
   }

  ngOnInit() {
  }

}
