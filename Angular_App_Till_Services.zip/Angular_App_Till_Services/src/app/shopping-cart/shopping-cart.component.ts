import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import { ProductService } from '../product/product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
heading:string="Online shopping";
companyName:string="";
productName:string="";
  listOfProducts: Product[] =[];

  constructor(private prodServObj:ProductService) { 
  }

  ngOnInit() {
    this.listOfProducts = this.prodServObj.GetAllProducts();

  }


  ChangeHeading(){
    this.heading = "Flipkart !";
  }
}
