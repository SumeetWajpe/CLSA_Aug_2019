import { Component, OnInit,Input } from '@angular/core';
import { Product } from '../product/product.model';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  isSelected:boolean=false;
  isFree:boolean=false;
  @Input() productdetails:Product = new Product();

  constructor(private servObj:ProductService) { }

  ngOnInit() {
  }

  DeleteProduct(){
    // biz logic
    this.servObj.DeleteAProduct(this.productdetails.id)
  }

}
