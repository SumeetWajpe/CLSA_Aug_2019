import {HttpClient} from '@angular/common/http'
import { Injectable } from '@angular/core';
import { Post } from './post.model';
import { Observable } from 'rxjs';

@Injectable({    providedIn:'root'})
export class PostsService{
    constructor(private httpClientObj:HttpClient){
    }
    getAllPosts():Observable<Post[]>{
        // AJAX request to get the data !       
     return this.httpClientObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts')
      
    }
}