import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';
import { Observable } from 'rxjs';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  allPosts:Post[];
  constructor(private postServObj:PostsService) { }

  ngOnInit() {
   let observablePosts = this.postServObj.getAllPosts();
   observablePosts.subscribe((response)=>{
     this.allPosts = response;
   });
  }

}
